# Ejemplo: compresi�n de im�genes con PCA
# Cargamos las librer�as, instalando si es necesario
install.packages2 <- function(package){
  if(!eval(parse(text=paste("require(",package,")")))){
    install.packages(package, dependencies = TRUE)
  return(eval(parse(text=paste("require(",package,")"))))}
}
install.packages2("jpeg")
install.packages2("FactoMineR")
install.packages2("grid")

# Cargamos la imagen con la que trabajaremos
gato <- readJPEG('gato.jpg')

# Notemos que una imagen en el espectro visible es representada por 
# tres matrices. Cada entrada corresponde a la descomposici�n del color
# en el pixel correspondiente en RGB (red/green/blue)
dim(gato)

# En particular en este caso, la im�gen est� representada por tres matrices de 398x600
r <- gato[,,1]
g <- gato[,,2]
b <- gato[,,3]

# Realizaremos an�lisis de componentes principales en cada una de las matrices
# que describen la imagen
r.pca <- prcomp(r, center = FALSE)
g.pca <- prcomp(g, center = FALSE)
b.pca <- prcomp(b, center = FALSE)

# Reunamos todos los resultados en una lista
rgb.pca <- list(r.pca, g.pca, b.pca)

# Recordemos que las componentes calculadas describen la variabilidad en cada matriz,
# de modo de realizar la compresi�n, s�lo debemos proyectar los datos sobre las componentes
# encontradas
for (i in seq.int(3, round(nrow(gato) - 10), length.out = 30)) {
  pca.img <- sapply(rgb.pca, function(j) {
    compressed.img <- j$x[,1:i] %*% t(j$rotation[,1:i])
  }, simplify = 'array')
  writeJPEG(pca.img, paste('compresion/pca/gato_comprimido_', round(i,0), '_componentes.jpg', sep = ''))
}

# Veamos cuanto logramos comprimir la imagen
original <- file.info('gato.jpg')$size / 1000
imgs <- dir('compresion/')
for (i in imgs) {
  full.path <- paste('compresion/', i, sep='')
  print(paste(i, ' size: ', file.info(full.path)$size / 1000, ' original: ', original, ' % diff: ', 
              round((file.info(full.path)$size / 1000 - original) / original, 2) * 100, '%', sep = ''))
}

# Ejemplo 2: Compresion de imagenes con k-means

# Procedemos tal y como en el ejemplo anterior, salvo que esta vez representamos el valor asociado a
# cada individuo con el valor del centro del cluster al que pertenece
rng<-seq(2,200, 10)
avg.totw.ss <-integer(length(rng)) #Set up an empty vector to hold all of points
for(v in 1:length(rng)){ # For each value of the range variable
  r.kmeans <- kmeans(r, rng[v], nstart = 20)
  g.kmeans <- kmeans(g, rng[v], nstart = 20)
  b.kmeans <- kmeans(b, rng[v], nstart = 20)
    
  # Calculamos la inercia promedio
  avg.totw.ss[v] <-(r.kmeans$tot.withinss + g.kmeans$tot.withinss + b.kmeans$tot.withinss)/3
}
plot(rng,avg.totw.ss,type="b", main="Inercia total para varios K",
     ylab="Inercia promedio",
     xlab="Valor de K")

# Veamos como quedo la imagen para 52, 102 y 152 grupos
r.kmeans <- kmeans(r, 102, nstart = 20)
g.kmeans <- kmeans(g, 102, nstart = 20)
b.kmeans <- kmeans(b, 102, nstart = 20)
# La funcion rgb nos permite crear la imagen a partir de las matrices r, g y b
r.compresion <- r.kmeans$centers[r.kmeans$cluster,]
g.compresion <- g.kmeans$centers[g.kmeans$cluster,]
b.compresion <- b.kmeans$centers[b.kmeans$cluster,]
kmeans.img <- rgb(r.compresion, g.compresion, b.compresion)
dim(kmeans.img) <- dim(r.compresion)
# Podemos ver como quedo la imagen
grid.raster(kmeans.img, interpolate=FALSE)

