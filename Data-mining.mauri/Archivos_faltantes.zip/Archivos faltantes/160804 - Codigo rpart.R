# Instalaci�n y carga de librer�as
install.packages("rpart",dependencies=TRUE)
library(rpart)
library(rpart.plot)

#Carga de datos y creaci�n de la tabla de aprendizaje y prueba
setwd("C:/Users/COMPUTER/Dropbox/Cursos UdeC/Cursos pregrado/Data Mining")
datos<-read.csv("MuestraCredito5000.csv",sep = ";",header=T)
muestra <-sample(1:5000,2500)
ttesting <-datos[muestra,]
taprendizaje <-datos[-muestra,]

# Recodifica las variables como cualitativas tabla de aprendizaje
taprendizaje$MontoCredito <-as.factor(taprendizaje$MontoCredito)
taprendizaje$IngresoNeto <-as.factor(taprendizaje$IngresoNeto)
taprendizaje$CoefCreditoAvaluo <-as.factor(taprendizaje$CoefCreditoAvaluo)
taprendizaje$MontoCuota <-as.factor(taprendizaje$MontoCuota)
taprendizaje$GradoAcademico <-as.factor(taprendizaje$GradoAcademico)
summary(taprendizaje)

# Generaci�n del modelo
modelo1 = rpart(BuenPagador~.,data=taprendizaje)
plot(modelo1)
text(modelo1)
prp(modelo1,extra=104,branch.type=2, box.col=c("red", "palegreen3")[modelo1$frame$yval])

# Recodifica las variables como cualitativas tabla de prueba
ttesting$MontoCredito <-as.factor(ttesting$MontoCredito)
ttesting$IngresoNeto <-as.factor(ttesting$IngresoNeto)
ttesting$CoefCreditoAvaluo <-as.factor(ttesting$CoefCreditoAvaluo)
ttesting$MontoCuota <-as.factor(ttesting$MontoCuota)
ttesting$GradoAcademico <-as.factor(ttesting$GradoAcademico)
summary(ttesting)

# Evaluando la calidad del modelo
prediccion <-predict(modelo1, ttesting, type='class')
MC<-table(ttesting$BuenPagador,prediccion)
MC
acierto<-(sum(diag(MC)))/sum(MC)
acierto
error<-1-acierto
error
