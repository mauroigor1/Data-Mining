library(FactoMineR)
library(caret)#Instalar si necesario

setwd("~/Dropbox/Cursos UdeC/Cursos pregrado/Data Mining/Reduccion de dimension y algo mas/Laboratorio y tarea 2")
file <- 'gisette_train.data'
gisetteRaw <- read.table(file, sep = '', header = FALSE, stringsAsFactors = FALSE)

#########PCA y HCPC#########
res<-PCA(gisetteRaw, scale.unit = TRUE, ncp = 5, ind.sup = NULL, 
         quanti.sup = NULL, quali.sup = NULL, row.w = NULL, 
         col.w = NULL, graph = TRUE, axes = c(1,2))

HCPC(res, nb.clust=0, consol=TRUE, iter.max=10, min=2, 
     max=NULL, metric="euclidean", method="ward", order=TRUE,
     graph.scale="inertia", nb.par=5, graph=TRUE, proba=0.05, 
     cluster.CA="rows",kk=Inf)

#########PCA y HCPC otra vez######
nzv <- nearZeroVar(gisetteRaw, saveMetrics = TRUE)
print(paste('Rango:',range(nzv$percentUnique)))
print(head(nzv))
print(paste('Conteo de columnas antes del corte:',ncol(gisetteRaw)))
dim(nzv[nzv$percentUnique > 0.1,])
gisette_nzv <- gisetteRaw[c(rownames(nzv[nzv$percentUnique > 0.1,])) ]
print(paste('Conteo de columnas despu?s del corte:',ncol(gisette_nzv)))

res<-PCA(gisette_nzv, scale.unit = TRUE, ncp = 5, ind.sup = NULL, 
         quanti.sup = NULL, quali.sup = NULL, row.w = NULL, 
         col.w = NULL, graph = TRUE, axes = c(1,2))

HCPC(res, nb.clust=0, consol=TRUE, iter.max=10, min=2, 
     max=NULL, metric="euclidean", method="ward", order=TRUE,
     graph.scale="inertia", nb.par=5, graph=TRUE, proba=0.05, 
     cluster.CA="rows",kk=Inf)



