setwd("C:/Users/alumno/Desktop/Lab_big_data")
Datos <- read.table("EjemploAlgoritmosRecomendacion.csv", header = TRUE, 
                    dec = ",", sep = ";", row.names = 1)
head(Datos)

#Funciones para calcular la matriz de distancia
minkowski <- function(x, y, p = 2) {
  if ((p < Inf) & (p > 0)) {
    s <- sum(abs(x - y)^p)^(1/p)
  } else if (p == Inf) {
    s <- max(abs(x - y))
  }
  return(s)
}
dist.matriz.minkowski <- function(M, p = 2) {
  n <- dim(M)[1]
  m <- dim(M)[2]
  D <- matrix(0, nrow = n, ncol = n)
  for (i in 1:n) {
    for (j in 1:n) {
      D[i, j] <- minkowski(Datos[i, ], Datos[j, ], p)
    }
  }
  rownames(D) <- rownames(M)
  colnames(D) <- rownames(M)
  return(as.dist(D))
}

#Tiempo de ejecucion dis
system.time(dist(Datos, method = "euclidean"))

#Tiempo de ejecucion de nuestras funciones
system.time(dist.matriz.minkowski(Datos))

##### El paquete ff #######
install.packages('ff',dependencies=TRUE)
install.packages('ffbase',dependencies=TRUE) #para tener las mismas funciones sin que importe
#estar en ff
install.packages('biglm',dependencies=TRUE)

suppressWarnings(suppressMessages(library(ff)))
suppressWarnings(suppressMessages(library(ffbase)))
suppressWarnings(suppressMessages(library(biglm)))

vec <- 1:10
class(vec)
vec_ff <- ff(vec)
class(vec_ff)

## algunas funciones
mean(vec)
mean(vec_ff)

#creando vectores grandes
y <- rep(0, 10^8)
x <- ff(0, length = 10^8)
x
x[100:125]

#Las siguientes funciones son de paquete ffbase
mean(x)
length(x)
system.time(mean(y)) #se demora mucho mas en ff
system.time(mean(x))

#Transformar un DataFrame de R en un DataFrame de ff
data(iris)
head(iris)
#Iris como DataFrame
iris_ff <- as.ffdf(iris)
class(iris_ff)
head(iris_ff)
str(iris_ff[,])
mean(iris_ff[,1])

idx <- ffwhich(iris_ff, Sepal.Width > 2) #cuales tienen largo de la sepa > 2
iris_ff[idx,]

# Se puede hacer una regresi�n sobre objetos ff usando el paquete 'bigglm'
iris_ff <- as.ffdf(iris)
mymodel <- biglm(Sepal.Length ~ Petal.Length, data = iris_ff)
coef(mymodel)

# Explicitando el nombre del archivo que usa ff
# Eso s�, un nombre de archivo solo se puede usar una vez en una
#sesi�n R
vector <- 1:10
ej1 <- ff(vector, filename = "arch1.mat", length = 10, overwrite =
            TRUE)
ej1
ej1[3:6]
length(ej1)





# Leyendo archivos gigantes usando 'read.csv.ffdf'
#La utilidad aqui es que leemos y dejamos guardado como objeto ff
#Y trabajar en R como si la tabla estuviera en RAM
ffDatos <- read.csv.ffdf(file = "EjemploAlgoritmosRecomendacion.csv",
                         header = TRUE,
                         sep = ";", dec = ",", row.names = 1)
ffDatos

BigDataE1 <- read.csv.ffdf(file = "BigDataE1.csv", sep = ";", dec = ",", header = TRUE)
head(BigDataE1)

mean1 <- function(x){
  n <- length(x)
  y <- 0
  for (i in 1:n){
     y <- x[i]+y
  }
   y <- y/n
   y
}

x <- sample(1:10, 10^8, replace = TRUE)
mean1(x)

####### otro paqetes ######

ffDatos <- read.csv.ffdf(file = "BigDataE1.csv", header = TRUE, sep
                         = ";", dec = ",")
dim(ffDatos)
PDatos <- read.csv("BigDataE1.csv", na.strings = "NULL", sep = ";",
                   dec = ",",
                   header = T)
dim(PDatos)
modelo <- biglm(Monto ~ Grado, data = ffDatos)
summary(modelo)
prediccion <- predict(modelo, newdata = ffDatos)

system.time(modelo1 <- biglm(Monto ~ Grado, data = ffDatos))




###### ##########
Datos <- read.csv("EjemploClientesCorregidaEdad.csv", header =
                    TRUE, sep = ";",
                  dec = ",", row.names = 1)
grupos = kmeans(Datos, 4, iter.max = 100, nstart = 100)
#nstart = con cuanto quiero hacer el promedio para validacion cruzada

# Comparando la salida
resultados1 <- list()
resultados2 <- list()
inercias1 <- rep(0, 10)
inercias2 <- rep(0, 10)
for (s in 1:10) {
  resultados1[[s]] <- kmeans(Datos, 4, nstart = 1)
  resultados2[[s]] <- kmeans(Datos, 4, nstart = 25)
  inercias1[s] <- resultados1[[s]]$tot.withinss
  inercias2[s] <- resultados2[[s]]$tot.withinss
}
inercias1 # Pueden dar diferentes con nstart=1
inercias2
plot(inercias1, type = "b", lwd = 1, col = "red", main = "Inercias
intra-clase",
     ylim = c(min(inercias1, inercias1), max(inercias1, inercias1) +
                10), xlab = "Iteraci�n",
     ylab = "Inercias")
lines(inercias2, col = "blue", type = "b", lwd = 1)
legend("topright", legend = c("nstart=1", "nstart=25"), lty = 1,
       col = c("red",
               "blue"))
system.time(kmeans(Datos, 4, nstart = 2500))
system.time(kmeans(Datos, 4, nstart = 25000))

library(MASS)
library(snow)
install.packages("snow", dependencies = TRUE)
# nstart=N�mero de muestras aleatorias iniciales Repite 4 veces
#kmeans con
# nstart=25 con un 'for', o sea c�digo tipo estructurado
resultados <- list()
inercias <- rep(0, 4)
for (k in 1:4) {
  resultados[[k]] <- kmeans(Boston, 4, nstart = 25)
  inercias[k] <- resultados[[k]]$tot.withinss
}
resultados <- resultados[[which.min(inercias)]]
inercias # Todos dan igual debido a que nstart=25
#y la inercia queda estable

# El c�digo debe ser transformado para usar lapply o sapply el cual
#repite 4
# veces kmeans con nstart=25 c�digo tipo funcional
# con esto voy a suplir el for que hicimos antes
resultados <- lapply(c(25, 25, 25, 25), function(n.muestras)
  kmeans(Boston,
         4, nstart = n.muestras))
inercias <- sapply(resultados, function(resultados)
  resultados$tot.withinss)
resultados <- resultados[[which.min(inercias)]]
inercias

 ###### resultados ########
resultados <- lapply(c(1, 10, 25), function(n.muestras)
  kmeans(Boston,
         4, nstart = n.muestras))
inercias <- sapply(resultados, function(resultados)
  resultados$tot.withinss)
resultados <- resultados[[which.min(inercias)]]
inercias

####################
x <- 1:100
resultados <- lapply(x, function(n.muestras)
  kmeans(Boston,
         4, nstart = n.muestras))
inercias <- sapply(resultados, function(resultados)
  resultados$tot.withinss)
resultados <- resultados[[which.min(inercias)]]
inercias

####################
# usaremos 4 'peones' en una m�quina local usando un 'socket'
cl <- makeCluster(4, type = "SOCK")
# carga el paquete MASS en cada pe�n haciendo visibles la Tabla de
Datos
# Boston en cada peon o procesador, aqui cargamos la tabla de datos en cada
#peon
ignore <- clusterEvalQ(cl, {
  library(MASS)
  NULL
})

#Aqui hace que cada peon haga un trabajo
resultados <- clusterApply(cl, c(25, 25, 25, 25),
                           function(n.muestras) kmeans(Boston,
                                                       4, nstart = n.muestras))
inercias <- sapply(resultados, function(resultado)
  resultado$tot.withinss)
resultado <- resultados[[which.min(inercias)]] # Se queda con el
#mejor resultado
inercias
